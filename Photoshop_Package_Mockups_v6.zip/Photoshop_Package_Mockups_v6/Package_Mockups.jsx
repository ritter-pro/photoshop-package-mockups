#target photoshop
app.bringToFront();
/* Package Mockups 6.0 — ExtendScript ES3, Photoshop desktop.
   PDF pixels are imported, never OCR'd or regenerated. */
(function () {
    var S = 3000, ROOT = new File($.fileName).parent;
    var oldUnits = app.preferences.rulerUnits, oldDialogs = app.displayDialogs;
    var report = [], stopped = false;
    function sid(s) { return stringIDToTypeID(s); }
    function cid(s) { return charIDToTypeID(s); }
    function fail(s) { throw new Error(s); }
    function rgb(d) { d.activeChannels=[d.channels[0],d.channels[1],d.channels[2]]; }
    function num(x) { return x.as('px'); }
    function bounds(l) { var b=l.bounds; return [num(b[0]),num(b[1]),num(b[2]),num(b[3])]; }
    function box(l) { var b=bounds(l);return {x:b[0],y:b[1],w:b[2]-b[0],h:b[3]-b[1]}; }
    function rect(d,r) { d.selection.select([[r.x,r.y],[r.x+r.w,r.y],[r.x+r.w,r.y+r.h],[r.x,r.y+r.h]]); }
    function moveFit(d,l,r,stretch) {
        app.activeDocument=d;d.activeLayer=l;var b=box(l);
        if(b.w<=0||b.h<=0)fail('Пустой слой: '+l.name);
        var sx=r.w/b.w*100,sy=r.h/b.h*100;
        if(!stretch)sx=sy=Math.min(sx,sy);
        l.resize(sx,sy,AnchorPosition.MIDDLECENTER);b=box(l);
        l.translate(r.x+(r.w-b.w)/2-b.x,r.y+(r.h-b.h)/2-b.y);
    }
    function newDoc(name) {
        var d=app.documents.add(UnitValue(S,'px'),UnitValue(S,'px'),300,name,NewDocumentMode.RGB,DocumentFill.TRANSPARENT,1,BitsPerChannelType.EIGHT,'sRGB IEC61966-2.1');
        return d;
    }
    function closeDoc(d) { try { d.close(SaveOptions.DONOTSAVECHANGES); } catch(e) {} }
    var imageCache={},cachedDocs=[];
    function importImage(f,d,name) {
        var cacheable=f.parent.name==='assets',key=f.fsName,t=imageCache[key],l;
        if(!t){t=app.open(f);try{t.trim(TrimType.TRANSPARENT,true,true,true,true);}catch(e){closeDoc(t);throw e;}
            if(cacheable){imageCache[key]=t;cachedDocs.push(t);}}
        try {app.activeDocument=t;l=t.activeLayer.duplicate(d,ElementPlacement.PLACEATBEGINNING);}
        finally {if(!cacheable)closeDoc(t);}
        app.activeDocument=d;l.name=name;return l;
    }
    function pdfPage(f,page) {
        var o=new PDFOpenOptions();o.page=page;o.usePageNumber=true;
        o.resolution=450;o.mode=OpenDocumentMode.RGB;o.bitsPerChannel=BitsPerChannelType.EIGHT;
        o.antiAlias=true;o.cropPage=CropToType.TRIMBOX;o.suppressWarnings=true;
        return app.open(f,o);
    }
    function importPDF(src,d,name,r,stretch) {
        app.activeDocument=src;var w=num(src.width),h=num(src.height);
        var l=src.activeLayer.duplicate(d,ElementPlacement.PLACEATBEGINNING);
        app.activeDocument=d;l.name=name;
        // Resize using PAGE size, including transparent margins, not visible layer bounds.
        var b=bounds(l),sx=r.w/w*100,sy=r.h/h*100;
        if(!stretch)sx=sy=Math.min(sx,sy);
        l.resize(sx,sy,AnchorPosition.TOPLEFT);
        var nb=bounds(l);
        l.translate(r.x+b[0]*sx/100-nb[0],r.y+b[1]*sy/100-nb[1]);
        return l;
    }
    function alpha(d,l) {
        app.activeDocument=d;d.activeLayer=l;
        var a=new ActionDescriptor(),r=new ActionReference(),t=new ActionReference();
        r.putProperty(cid('Chnl'),cid('fsel'));a.putReference(cid('null'),r);
        t.putEnumerated(cid('Chnl'),cid('Chnl'),cid('Trsp'));a.putReference(cid('T   '),t);
        executeAction(cid('setd'),a,DialogModes.NO);
    }
    function saveSelection(d,name) {var c=d.channels.add();c.name=name;d.selection.store(c);rgb(d);return c;}
    function maskSelected(d,l) {
        app.activeDocument=d;d.activeLayer=l;
        var a=new ActionDescriptor(),r=new ActionReference();
        a.putClass(cid('Nw  '),cid('Chnl'));r.putEnumerated(cid('Chnl'),cid('Chnl'),cid('Msk '));
        a.putReference(cid('At  '),r);a.putEnumerated(cid('Usng'),cid('UsrM'),cid('RvlS'));
        executeAction(cid('Mk  '),a,DialogModes.NO);d.selection.deselect();rgb(d);
    }
    function wand(d,l,x,y,contiguous) {
        d.activeLayer=l;rgb(d);var a=new ActionDescriptor(),r=new ActionReference(),p=new ActionDescriptor();
        r.putProperty(cid('Chnl'),cid('fsel'));a.putReference(cid('null'),r);
        p.putUnitDouble(cid('Hrzn'),cid('#Pxl'),x);p.putUnitDouble(cid('Vrtc'),cid('#Pxl'),y);
        a.putObject(cid('T   '),cid('Pnt '),p);a.putInteger(cid('Tlrn'),2);
        a.putBoolean(cid('AntA'),true);a.putBoolean(cid('Cntg'),!!contiguous);a.putBoolean(cid('Mrgd'),false);
        executeAction(cid('setd'),a,DialogModes.NO);
    }
    function colorRange(d,l,hex,fuzz) {
        app.activeDocument=d;d.activeLayer=l;rgb(d);
        var c=new SolidColor();c.rgb.hexValue=hex;
        var a=new ActionDescriptor(),v=new ActionDescriptor();
        v.putDouble(cid('Lmnc'),c.lab.l);v.putDouble(cid('A   '),c.lab.a);v.putDouble(cid('B   '),c.lab.b);
        a.putInteger(cid('Fzns'),fuzz);a.putObject(cid('Mnm '),cid('LbCl'),v);a.putObject(cid('Mxm '),cid('LbCl'),v);
        executeAction(cid('ClrR'),a,DialogModes.NO);
    }
    function selectionBox(d) {try {var b=d.selection.bounds;return {x:num(b[0]),y:num(b[1]),w:num(b[2])-num(b[0]),h:num(b[3])-num(b[1])};}catch(e){return null;}}
    function hardSelection(d) {
        var ch=saveSelection(d,'TEMP_BINARY');d.selection.deselect();d.activeChannels=[ch];
        var a=new ActionDescriptor();a.putInteger(cid('Lvl '),1);
        executeAction(cid('Thrs'),a,DialogModes.NO);
        rgb(d);d.selection.load(ch);ch.remove();
    }
    function preparePDF(d,c,assets,isFront) {
        // Work on PDF alone: Color Range must never sample the bag or products.
        app.activeDocument=d;var l=d.activeLayer,W=num(d.width),H=num(d.height),win=null,hole=null;
        if(isFront&&c.gray) {
            colorRange(d,l,c.hex,c.fuzz);hardSelection(d);
            var allGray=saveSelection(d,'TEMP_ALL_GRAY');
            // Placement uses the connected window background, not stray gray pixels in diagrams.
            var sampler=d.colorSamplers.add([UnitValue(W*.85,'px'),UnitValue(H*.65,'px')]);
            var sampled=sampler.color.rgb,target=new SolidColor();target.rgb.hexValue=c.hex;
            var delta=Math.max(Math.abs(sampled.red-target.rgb.red),Math.abs(sampled.green-target.rgb.green),Math.abs(sampled.blue-target.rgb.blue));sampler.remove();
            if(delta>16){allGray.remove();fail('Точка внутри окна не попала на серый фон. Требуется настройка точки поиска окна в preparePDF.');}
            wand(d,l,W*.85,H*.65,true);win=selectionBox(d);
            d.selection.load(allGray);allGray.remove();
            if(!win||win.w<W*.1||win.h<H*.1)fail('Серый фон не найден. Проверьте HEX цвета в едином окне настроек.');
            d.selection.clear();d.selection.deselect();
        }
        // Search WHITE pixels on the PURPLE half of the header only.
        // Mirror detected left half to obtain the original centered euro slot bounds.
        colorRange(d,l,'FFFFFF',0);
        var white=saveSelection(d,'TEMP_WHITE');
        rect(d,{x:W*.28,y:H*.015,w:W*.219,h:H*.105});
        d.selection.load(white,SelectionType.INTERSECT);var old=selectionBox(d);white.remove();
        if(old&&old.w>W*.035&&old.h>H*.01&&old.h<H*.12) {
            // Copy a clean header stripe BELOW the slot, never the logo to its left.
            // On back restore the WHOLE old slot, not just the purple left half.
            d.selection.deselect();
            var pad=Math.max(8,W*.003),slotWidth=W-2*old.x;
            var targetBox={x:old.x-pad,y:old.y-pad,w:slotWidth+2*pad,h:old.h+2*pad};
            if(isFront)targetBox.w=W/2-targetBox.x;
            var donor={x:targetBox.x,y:old.y+old.h+H*.008,w:targetBox.w,h:H*.023};
            rect(d,donor);d.activeLayer=l;rgb(d);d.selection.copy();
            var patch=d.paste();patch.name='Паттерн вместо старого отверстия';
            moveFit(d,patch,targetBox,true);d.selection.deselect();
            l=patch.merge();d.activeLayer=l;
            var fullWidth=W-2*old.x,shrink=0.70;
            hole={x:(W-fullWidth*shrink)/2/W,y:(old.y+old.h*(1-shrink)/2)/H,w:fullWidth*shrink/W,h:old.h*shrink/H};
            var h=importImage(assets.hole,d,'TEMP_HOLE');
            moveFit(d,h,{x:hole.x*W,y:hole.y*H,w:hole.w*W,h:hole.h*H},true);
            alpha(d,h);d.selection.expand(1);d.activeLayer=l;rgb(d);d.selection.clear();d.selection.deselect();h.remove();
        }
        d.selection.deselect();
        if(!hole)fail('Не удалось определить белое евроотверстие на фиолетовой половине PDF. Файл пропущен, чтобы не вырезать печать ошибочно.');
        if(isFront&&!win) { // Already transparent window: infer from alpha, not a percentage crop.
            alpha(d,l);d.selection.invert();
            // Original euro slot is excluded by limiting this inference to the lower half.
            var trans=saveSelection(d,'TEMP_TRANS');rect(d,{x:0,y:H*.2,w:W,h:H*.8});
            d.selection.load(trans,SelectionType.INTERSECT);win=selectionBox(d);trans.remove();d.selection.deselect();
            if(!win||win.w<W*.1||win.h<H*.1)fail('Прозрачное окно не обнаружено. Включите удаление серого по цвету.');
        }
        d.activeLayer=l;rgb(d);
        return {window:win?{x:win.x/W,y:win.y/H,w:win.w/W,h:win.h/H}:null,hole:hole};
    }
    function shadow(d,g) {
        d.activeLayer=g;var a=new ActionDescriptor(),r=new ActionReference(),fx=new ActionDescriptor(),sh=new ActionDescriptor(),c=new ActionDescriptor();
        r.putProperty(cid('Prpr'),cid('Lefx'));r.putEnumerated(cid('Lyr '),cid('Ordn'),cid('Trgt'));a.putReference(cid('null'),r);
        fx.putUnitDouble(cid('Scl '),cid('#Prc'),100);sh.putBoolean(cid('enab'),true);
        sh.putEnumerated(cid('Md  '),cid('BlnM'),cid('Mltp'));c.putDouble(cid('Rd  '),0);c.putDouble(cid('Grn '),0);c.putDouble(cid('Bl  '),0);
        sh.putObject(cid('Clr '),cid('RGBC'),c);sh.putUnitDouble(cid('Opct'),cid('#Prc'),88);
        sh.putBoolean(cid('uglg'),false);sh.putUnitDouble(cid('lagl'),cid('#Ang'),120);
        sh.putUnitDouble(cid('Dstn'),cid('#Pxl'),16);sh.putUnitDouble(cid('Ckmt'),cid('#Pxl'),23);sh.putUnitDouble(cid('blur'),cid('#Pxl'),46);
        sh.putBoolean(sid('present'),true);sh.putBoolean(sid('showInDialog'),true);
        sh.putBoolean(cid('AntA'),true);sh.putUnitDouble(cid('Nose'),cid('#Prc'),0);
        sh.putBoolean(sid('layerConceals'),true);
        var contour=new ActionDescriptor();contour.putString(cid('Nm  '),'Linear');
        sh.putObject(cid('TrnS'),cid('ShpC'),contour);
        fx.putObject(cid('DrSh'),cid('DrSh'),sh);a.putObject(cid('T   '),cid('Lefx'),fx);
        executeAction(cid('setd'),a,DialogModes.NO);
    }
    function article(f) {
        var n=decodeURI(f.name),m=n.match(/^\s*(\d{4,})(?:[ _-]+(\d)(?=[^\d]|$))?/);
        if(!m)fail('Не найден артикул в начале имени PDF: '+n);
        return m[1]+(m[2]||'');
    }
    var productIndex=null;
    function findProduct(root,key) {
        var hits=[];
        function walk(folder) {var fs=folder.getFiles();for(var i=0;i<fs.length;i++) {
            if(fs[i] instanceof Folder)walk(fs[i]);
            else if(/\.(png|psd|tif|tiff)$/i.test(fs[i].name)) {
                try {var code=article(fs[i]);if(!productIndex[code])productIndex[code]=[];productIndex[code].push(fs[i]);}catch(e){}
            }
        }}
        if(productIndex===null){productIndex={};walk(root);}
        hits=productIndex[key]||[];
        if(hits.length===1)return hits[0];
        return File.openDialog((hits.length?'Несколько изображений':'Не найден товар')+' для '+key+'. Выберите нужный файл','Изображения:*.png;*.psd;*.tif;*.tiff',false);
    }
    function asset(name) {var f=new File(ROOT+'/assets/'+name+'.png');if(!f.exists)fail('Не найден '+f.fsName);return f;}
    function entry(key,last) {
        var w=new Window('dialog','Артикул '+key);w.orientation='column';w.alignChildren='fill';
        function field(label,value) {var g=w.add('group');g.add('statictext',undefined,label);var e=g.add('edittext',undefined,String(value));e.characters=10;return e;}
        var count=field('Количество',last),size=field('Размер товара: % от ширины пакета',26);
        w.add('statictext',undefined,'Область товара: % от размера пакета');
        var left=field('Слева, %',5),upper=field('Сверху, %',44);
        var areaW=field('Ширина области, %',90),areaH=field('Высота области, %',42);
        var hex=field('Серый фон: HEX без #','BBBDBF');
        var fuzz=field('Допуск выделения цвета (0–200)',6);
        var gray=w.add('checkbox',undefined,'Удалить серый цвет на всём слое PDF');gray.value=true;
        var review=w.add('checkbox',undefined,'Оставить для проверки перед сохранением');review.value=false;
        var psd=w.add('checkbox',undefined,'Сохранить также PSD со слоями');psd.value=true;
        var g=w.add('group');g.add('button',undefined,'Собрать',{name:'ok'});g.add('button',undefined,'Пропустить',{name:'cancel'});
        if(w.show()!==1)return null;
        var n=Number(count.text),pct=Number(size.text.replace(',','.')),tol=Number(fuzz.text),color=hex.text.replace('#','');
        if(n<1||n>1000||n!==Math.floor(n)||pct<=0||pct>100||tol<0||tol>200||!isFinite(n+pct+tol)||!/^([0-9a-f]{6})$/i.test(color))fail('Проверьте количество, размер, цвет и допуск.');
        var ax=Number(left.text.replace(',','.'))/100,ay=Number(upper.text.replace(',','.'))/100;
        var aw=Number(areaW.text.replace(',','.'))/100,ah=Number(areaH.text.replace(',','.'))/100;
        if(!isFinite(ax+ay+aw+ah)||ax<0||ay<0||aw<=0||ah<=0||ax+aw>1||ay+ah>1)fail('Область товара должна находиться внутри пакета.');
        return {area:{x:ax,y:ay,w:aw,h:ah},n:n,size:pct,hex:color,fuzz:Math.round(tol),gray:gray.value,review:review.value,psd:psd.value};
    }
    function transformProduct(d,l,b,scale,angle,cx,cy) {
        d.activeLayer=l;
        var a=new ActionDescriptor(),ref=new ActionReference(),offset=new ActionDescriptor();
        ref.putEnumerated(cid('Lyr '),cid('Ordn'),cid('Trgt'));a.putReference(cid('null'),ref);
        a.putEnumerated(cid('FTcs'),cid('QCSt'),cid('Qcsa'));
        offset.putUnitDouble(cid('Hrzn'),cid('#Pxl'),cx-(b.x+b.w/2));
        offset.putUnitDouble(cid('Vrtc'),cid('#Pxl'),cy-(b.y+b.h/2));
        a.putObject(cid('Ofst'),cid('Ofst'),offset);
        a.putUnitDouble(cid('Wdth'),cid('#Prc'),scale*100);a.putUnitDouble(cid('Hght'),cid('#Prc'),scale*100);
        a.putUnitDouble(cid('Angl'),cid('#Ang'),angle);
        executeAction(cid('Trnf'),a,DialogModes.NO);
    }
    function products(d,g,f,n,r,productSize) {
        var pg=g.layerSets.add();pg.name='02 Товар — '+n+' шт. (без обрезки теней)';pg.blendMode=BlendMode.NORMAL;
        var master=importImage(f,d,'TEMP_PRODUCT_MASTER');master.move(pg,ElementPlacement.INSIDE);master.visible=false;
        var b=box(master),cols=Math.ceil(Math.sqrt(n*r.w/r.h)),rows=Math.ceil(n/cols),cw=r.w/cols,ch=r.h/rows;
        for(var i=0;i<n;i++) {
            var l=master.duplicate();l.visible=true;l.name='Товар '+(i+1);
            var angle=Math.random()*360,rad=angle*Math.PI/180;
            var co=Math.abs(Math.cos(rad)),si=Math.abs(Math.sin(rad));
            var scale=productSize/Math.max(b.w,b.h)*(0.95+Math.random()*.10);
            var rotatedW=(b.w*co+b.h*si)*scale,rotatedH=(b.w*si+b.h*co)*scale;
            var fit=Math.min(1,r.w/rotatedW,r.h/rotatedH);scale*=fit;rotatedW*=fit;rotatedH*=fit;
            var cx=r.x+(i%cols+.5)*cw+(Math.random()-.5)*cw*.35;
            var cy=r.y+(Math.floor(i/cols)+.5)*ch+(Math.random()-.5)*ch*.35;
            cx=Math.max(r.x+rotatedW/2,Math.min(r.x+r.w-rotatedW/2,cx));
            cy=Math.max(r.y+rotatedH/2,Math.min(r.y+r.h-rotatedH/2,cy));
            transformProduct(d,l,b,scale,angle,cx,cy);shadow(d,l);
        }
        master.remove();return pg;
    }
    function cutHole(d,g,r,shape,hole) {
        var h=importImage(shape,d,'Евроотверстие — шаблон (скрыт)');
        moveFit(d,h,{x:r.x+r.w*hole.x,y:r.y+r.h*hole.y,w:r.w*hole.w,h:r.h*hole.h},true);
        alpha(d,h);d.selection.expand(1);var hc=saveSelection(d,'TEMP_HOLE');h.visible=false;
        // Existing outer mask was not yet made: combine base silhouette minus hole in one mask.
        d.selection.load(shapeChannel);d.selection.load(hc,SelectionType.DIMINISH);maskSelected(d,g);hc.remove();
    }
    var shapeChannel;
    function front(src,product,c,key,assets) {
        var info=preparePDF(src,c,assets,true);
        var d=newDoc(key+' — лицевая');var blank=d.activeLayer;
        var rw=num(src.width),rh=num(src.height),s=Math.min(2800/rw,2800/rh);
        var r={x:(S-rw*s)/2,y:(S-rh*s)/2,w:rw*s,h:rh*s};
        var g=d.layerSets.add();g.name='ПАКЕТ';g.blendMode=BlendMode.NORMAL;
        var base=importImage(assets.base,d,'01 Основа');moveFit(d,base,r,true);base.move(g,ElementPlacement.INSIDE);
        alpha(d,base);shapeChannel=saveSelection(d,'TEMP_PACKAGE');d.selection.deselect();
        var wr=info.window;
        var inset=Math.max(8,r.w*.015);
        var win={x:r.x+r.w*wr.x+inset,y:r.y+r.h*wr.y+inset,w:r.w*wr.w-2*inset,h:r.h*wr.h-2*inset};
        var requested={x:r.x+r.w*c.area.x,y:r.y+r.h*c.area.y,w:r.w*c.area.w,h:r.h*c.area.h};
        var x1=Math.max(win.x,requested.x),y1=Math.max(win.y,requested.y);
        var x2=Math.min(win.x+win.w,requested.x+requested.w),y2=Math.min(win.y+win.h,requested.y+requested.h);
        win={x:x1,y:y1,w:x2-x1,h:y2-y1};
        if(win.w<=0||win.h<=0)fail('Область товара слишком мала.');
        var pg=products(d,g,product,c.n,win,r.w*c.size/100);pg.move(base,ElementPlacement.PLACEBEFORE);
        var art=importPDF(src,d,'03 PDF — страница 1',r,true);art.move(pg,ElementPlacement.PLACEBEFORE);
        var top=importImage(c.n===1?assets.single:assets.zip,d,'04 Блики — Screen');moveFit(d,top,r,true);
        top.opacity=100;top.blendMode=BlendMode.SCREEN;top.move(art,ElementPlacement.PLACEBEFORE);
        cutHole(d,g,r,assets.hole,info.hole);shapeChannel.remove();blank.remove();return d;
    }
    function back(src,key,assets) {
        var info=preparePDF(src,{},assets,false);
        var d=newDoc(key+' — оборот');var blank=d.activeLayer,g=d.layerSets.add();g.name='ОБОРОТ';g.blendMode=BlendMode.NORMAL;
        var pw=num(src.width),ph=num(src.height),scale=Math.min(2800/pw,2800/ph);
        var r={x:(S-pw*scale)/2,y:(S-ph*scale)/2,w:pw*scale,h:ph*scale};
        var l=importPDF(src,d,'PDF — страница 2',r,false);l.move(g,ElementPlacement.INSIDE);
        rect(d,r);shapeChannel=saveSelection(d,'TEMP_RECT');cutHole(d,g,r,assets.hole,info.hole);shapeChannel.remove();blank.remove();return d;
    }
    function save(d,folder,key,psd) {
        app.activeDocument=d;
        if(psd){var po=new PhotoshopSaveOptions();po.layers=true;d.saveAs(new File(folder+'/'+key+'.psd'),po,true,Extension.LOWERCASE);}
        var o=new PNGSaveOptions();o.interlaced=false;d.saveAs(new File(folder+'/'+key+'.png'),o,true,Extension.LOWERCASE);
    }
    try {
        app.preferences.rulerUnits=Units.PIXELS;app.displayDialogs=DialogModes.NO;
        var assets={base:asset('base'),zip:asset('zip'),single:asset('single'),hole:asset('hole')};
        var pdfs=File.openDialog('Выберите PDF для обработки','PDF:*.pdf',true);if(!pdfs)return;if(!(pdfs instanceof Array))pdfs=[pdfs];
        var pf=Folder.selectDialog('Папка с единичными товарами (поиск во вложенных папках)');if(!pf)return;
        var dest=Folder.selectDialog('Куда сохранить результат');if(!dest)return;
        var ff=new Folder(dest+'/front'),bf=new Folder(dest+'/back');if(!ff.exists&&!ff.create())fail('Не создать front');if(!bf.exists&&!bf.create())fail('Не создать back');
        var last=10;
        for(var i=0;i<pdfs.length;i++) {
            var a=null,b=null,fd=null,bd=null,key='?';
            try {
                key=article(pdfs[i]);
                if(new File(ff+'/'+key+'.png').exists||new File(bf+'/'+key+'.png').exists||new File(ff+'/'+key+'.psd').exists||new File(bf+'/'+key+'.psd').exists){report.push(key+': пропуск, результат уже существует');continue;}
                var c=entry(key,last);if(!c){report.push(key+': пропущен пользователем');continue;}last=c.n;
                var product=findProduct(pf,key);if(!product){report.push(key+': пропуск, товар не выбран');continue;}
                a=pdfPage(pdfs[i],1);b=pdfPage(pdfs[i],2);
                fd=front(a,product,c,key,assets);bd=back(b,key,assets);closeDoc(a);a=null;closeDoc(b);b=null;
                if(c.review) {
                    app.activeDocument=fd;app.displayDialogs=oldDialogs;
                    alert('Сборка '+key+' готова. После закрытия сообщений проверьте оба документа и поправьте слои при необходимости. Затем запустите Continue_Save.jsx. Режим проверки обрабатывает один артикул за запуск; для больших партий снимите флажок проверки.');
                    var note=new File(dest+'/'+key+'_pending.txt');note.encoding='UTF8';note.open('w');note.write('Документы: '+fd.name+' / '+bd.name+'\nСохраните через Continue_Save.jsx\n');note.close();
                    report.push(key+': оставлены открытыми для проверки; PNG ещё не сохранены');fd=null;bd=null;
                    // Review mode handles one article per invocation to avoid hundreds of open documents.
                    stopped=true;break;
                }
                save(fd,ff,key,c.psd);save(bd,bf,key,c.psd);report.push(key+': OK');
            } catch(e) {report.push(key+': ОШИБКА '+e.message+' (строка '+e.line+')');}
            finally {if(a)closeDoc(a);if(b)closeDoc(b);if(fd)closeDoc(fd);if(bd)closeDoc(bd);}
        }
        var log=new File(dest+'/mockup_log_'+new Date().getTime()+'.txt');log.encoding='UTF8';if(log.open('w')){log.write(report.join('\n'));log.close();}
        alert(report.join('\n')+(stopped?'\n\nРежим проверки: для следующего артикула запустите основной скрипт снова.':''));
    } catch(e) {alert('Сборка остановлена: '+e.message+'\nСтрока '+e.line);}
    finally {for(var cacheIndex=0;cacheIndex<cachedDocs.length;cacheIndex++)closeDoc(cachedDocs[cacheIndex]);app.preferences.rulerUnits=oldUnits;app.displayDialogs=oldDialogs;}
}());
