#target photoshop
(function(){
 var pairs={},i,d,m,key,root,old=app.displayDialogs;
 try{
  for(i=0;i<app.documents.length;i++){
   d=app.documents[i];m=d.name.match(/^(\d+) — (лицевая|оборот)$/);
   if(m){key=m[1];if(!pairs[key])pairs[key]={};pairs[key][m[2]=== 'лицевая'?'front':'back']=d;}
  }
  var keys=[];for(key in pairs)if(pairs.hasOwnProperty(key)&&pairs[key].front&&pairs[key].back)keys.push(key);
  if(!keys.length){alert('Не найдена пара документов «артикул — лицевая / оборот». Не переименовывайте документы до сохранения.');return;}
  root=Folder.selectDialog('Выберите папку результата');if(!root)return;
  var front=new Folder(root+'/front'),back=new Folder(root+'/back');if(!front.exists)front.create();if(!back.exists)back.create();
  app.displayDialogs=DialogModes.NO;
  for(i=0;i<keys.length;i++){
   key=keys[i];var dirs=[front,back],docs=[pairs[key].front,pairs[key].back];
   for(var k=0;k<2;k++){
    if(new File(dirs[k]+'/'+key+'.png').exists||new File(dirs[k]+'/'+key+'.psd').exists)throw new Error('Файлы '+key+' уже существуют: сохранение остановлено без перезаписи.');
   }
   for(var j=0;j<2;j++){
    d=docs[j];app.activeDocument=d;
    var ps=new PhotoshopSaveOptions();ps.layers=true;d.saveAs(new File(dirs[j]+'/'+key+'.psd'),ps,true,Extension.LOWERCASE);
    var pn=new PNGSaveOptions();pn.interlaced=false;d.saveAs(new File(dirs[j]+'/'+key+'.png'),pn,true,Extension.LOWERCASE);
   }
  }
  alert('Сохранено пар: '+keys.length+'. Документы оставлены открытыми.');
 }catch(e){alert('Ошибка: '+e.message+' / строка '+e.line);}finally{app.displayDialogs=old;}
}());
